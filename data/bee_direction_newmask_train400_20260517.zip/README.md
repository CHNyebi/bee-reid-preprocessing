﻿# Bee direction labeled dataset

400 already horizontally aligned masked bee crops for the three-class ResNet18 direction classifier.

Labels: head_left, head_right, unclear.

These samples were generated with the new foreground mask pipeline and are intended for the mask-only orientation normalizer.
